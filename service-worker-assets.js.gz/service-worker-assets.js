self.assetsManifest = {
  "version": "3g1Lo9zE",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-wM8xoXP2L+CqUYHe3TIpJrGysLtdZS34D5Y9xx83QaM=",
      "url": "Evanston.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-pxoL0sR+rW8FeySiRHjFptIGusn0BFRre4j7xSLzJrY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-JIdvZz+p6bMt7bvlJ0UxWaJNf/8AADBtXlwwd75JwMM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-9LnbSxYbqVRmau4Cor35q/7ONr9W8qrIcE3lCs3ussE=",
      "url": "_framework/Evanston.k84qqi8f9a.wasm"
    },
    {
      "hash": "sha256-/w5E7LJWBLa7so0LcXK/PLpE/fNwPErxJhlVfGasCAo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.x80val28il.wasm"
    },
    {
      "hash": "sha256-h9GyUb8vWLcAiCDULxHGLZLlN6c1ZLVzM97HqFVE5n4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.z92snw2zcg.wasm"
    },
    {
      "hash": "sha256-YcQQY/nHMOb3wYqd8dsqSmvcA87hI+Pp57nagR5w9ZY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.fglwvu9j8s.wasm"
    },
    {
      "hash": "sha256-xNe+dIBgdHgDLWL+DSdG899wNccao3q3MGotDUpGdkY=",
      "url": "_framework/Microsoft.AspNetCore.Components.smpoct2sk5.wasm"
    },
    {
      "hash": "sha256-SvqIqLTJFeFnn2GyYARDkqvF//mAgsCnCMAO0bMqo60=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.e7obn5k3m8.wasm"
    },
    {
      "hash": "sha256-X+g8Y9v8Xs3DURC3DvFf0BXk5Ll4hWN5k4Oc+3lBALE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.this79iyc7.wasm"
    },
    {
      "hash": "sha256-AfgiKXj2TZbhvV4OmBVd8zf36SdWtLxp9dIGGJ3QRbY=",
      "url": "_framework/Microsoft.Extensions.Configuration.zr9y6n6fms.wasm"
    },
    {
      "hash": "sha256-NK3wOaH7fMQobiztYI2170HXia5UNpvRSRL+0XLRY8k=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4k6089g733.wasm"
    },
    {
      "hash": "sha256-rW0muBNtI+FY/WA4kKZ6KaamvExUL3czb1N7sbPc6K4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t4styidezf.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-/lATVMaxjrO/7QTYnmE50qdHvr8l76pNE9v29HGzLeA=",
      "url": "_framework/Microsoft.Extensions.Logging.6vimitskgi.wasm"
    },
    {
      "hash": "sha256-fbD19XMFcHzFYLWPJ7gZT69PBsLIIf9XxvfH09/3y8w=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.v92sxplh8i.wasm"
    },
    {
      "hash": "sha256-vc8CWywpPFGVlV1s6BzM2iogrTlr8xfH22VaInhkpU4=",
      "url": "_framework/Microsoft.Extensions.Options.v5r7rgvi6o.wasm"
    },
    {
      "hash": "sha256-L5NQ4Q3qCOQCVq4fdxJDVX9+tmbCgm5IufwAOUFf37o=",
      "url": "_framework/Microsoft.Extensions.Primitives.330fdynik0.wasm"
    },
    {
      "hash": "sha256-52li3rv6uQT4TFUoqRLiSC0ztkV28vVbI7T+3qPRYzY=",
      "url": "_framework/Microsoft.JSInterop.1moab4w2ry.wasm"
    },
    {
      "hash": "sha256-EzPimVxYUyvc5hlmFOvopAur+oDc/0DNCvYv9ReoU70=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.pxf5p9f275.wasm"
    },
    {
      "hash": "sha256-oe6fr4aCRJ/SvFnWLBPYBAJlHETZw4xEfid2UQAU9vo=",
      "url": "_framework/MudBlazor.jzaj34egoz.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-6VytDSOGNIzTPHZZ9HgeiD7ZtdyMn9R7S5eeVZEzWvc=",
      "url": "_framework/System.Collections.Concurrent.vewcwpxtla.wasm"
    },
    {
      "hash": "sha256-mMtyePc+CFoXxNTH4mN28ImEPUynHGjLJInpmfdNsPI=",
      "url": "_framework/System.Collections.Immutable.8glk6j738d.wasm"
    },
    {
      "hash": "sha256-DCi5OxEjF4Rj2GyEy0307YqOLpD7KtybjH4qqOWVy/U=",
      "url": "_framework/System.Collections.wjwl0gx10w.wasm"
    },
    {
      "hash": "sha256-UK+J/g58lnN0cn707WR5PdM77Oj4soM0NJK+8PVkMyw=",
      "url": "_framework/System.ComponentModel.Annotations.styc8j8rs9.wasm"
    },
    {
      "hash": "sha256-Sol2kqkbON/CMBoSWXOcsANM9VUUsWHaZyLGgZzn4VY=",
      "url": "_framework/System.ComponentModel.Primitives.6k6ajhy10u.wasm"
    },
    {
      "hash": "sha256-6ezadFy7yEZhtzFCy/7fvvR1GyTYnCFzbq/d0Qphkn0=",
      "url": "_framework/System.ComponentModel.lhrz3xbrnu.wasm"
    },
    {
      "hash": "sha256-AybkzEOl56Vl43cNhRpd0OeWVN0QWnX6+5QuDBmDWoQ=",
      "url": "_framework/System.Console.zkpi4kkdp3.wasm"
    },
    {
      "hash": "sha256-+/Et4aS2nrSOeIRmVCWtkIIW/YLiKRwrx4kRes2H6LE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.xt9pws0gyn.wasm"
    },
    {
      "hash": "sha256-H1CHBmaAMS4PKAPtP+BRNwndUH6Sgof2IjdMGHxUFvI=",
      "url": "_framework/System.IO.Pipelines.j7hw5n5kz8.wasm"
    },
    {
      "hash": "sha256-3VG6yiLF4L4ZePImlG4g7UaqreQPPxkmEpby6TmsBBk=",
      "url": "_framework/System.Linq.Expressions.p553l0q96o.wasm"
    },
    {
      "hash": "sha256-ox/pSaCUkWudgX1/pAVICgDKUYpR8ona4RbPmKmEMKY=",
      "url": "_framework/System.Linq.hnpmhll50k.wasm"
    },
    {
      "hash": "sha256-K9fbUHZYDY9cbGXl2qb7fcREJHV/eV/KaODaqEeuncY=",
      "url": "_framework/System.Memory.rghra3t197.wasm"
    },
    {
      "hash": "sha256-1vxaHo/35D0kNWQEH77q2LEndmxTBYXZ9oY39h7xeNs=",
      "url": "_framework/System.Net.Http.2ph1hjljlv.wasm"
    },
    {
      "hash": "sha256-o70tGetBMzor7KrxH8FaZpvLHr550NiFT6cRAThdDYM=",
      "url": "_framework/System.Net.Http.Json.7rtw3b70rs.wasm"
    },
    {
      "hash": "sha256-apBfvYh1Ms3zCUF7mLUnYtXgFCFIagkC04eopFCYvSc=",
      "url": "_framework/System.Net.Primitives.um6s3v6dex.wasm"
    },
    {
      "hash": "sha256-HrgfUEEsN4SKESnTPa8wJQAIGdhOAthLwxreNU0VMgw=",
      "url": "_framework/System.Private.CoreLib.yg80tgyye7.wasm"
    },
    {
      "hash": "sha256-L68IA44nS8xizQDgsVCozN3FbFDAQTKXtrAsf4R1PCI=",
      "url": "_framework/System.Private.Uri.bdpnnq7lpi.wasm"
    },
    {
      "hash": "sha256-aBRJfPKhw/iL7CjlvetfKmPRKwQ1yZQqCeNMa2RgXfc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.c36vvrjj6t.wasm"
    },
    {
      "hash": "sha256-/d/JtrC92OiAl73lDhynn7eAmvW3vAHkEqEi1ShSyng=",
      "url": "_framework/System.Runtime.vpa37kpc4t.wasm"
    },
    {
      "hash": "sha256-1pYnog+hAQYG5AmoN8yPu2sN7VE8tXMsT6EUst0eUEo=",
      "url": "_framework/System.Text.Encodings.Web.az6magofqp.wasm"
    },
    {
      "hash": "sha256-/IlkjC8V0INqaMyNgEc/eYJaLhIj3jBqzF+LlheUVsI=",
      "url": "_framework/System.Text.Json.k6penrtu95.wasm"
    },
    {
      "hash": "sha256-y1CN5ibztU8h9CpKezQoacT3CYMXrtHmEx6DKWbtUwA=",
      "url": "_framework/System.Text.RegularExpressions.jec8s9wgcu.wasm"
    },
    {
      "hash": "sha256-XEsgkzB/5E/EJIekQAKL/++ZBvHe055n9Zo6Q2Ce2Zo=",
      "url": "_framework/System.Threading.cy526l72bt.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-9NNgOHiW+RpcrnAstKjxEdZxLO67RFH3S5/ym3za/E0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-BTZWVYmjU3il0nhi+FV9dvzO3XWNw9R+7u8lgvJ8AL8=",
      "url": "_framework/dotnet.native.fjwdof7fuz.js"
    },
    {
      "hash": "sha256-vEAPD+XWIUzh8fAUWKT6JRQrTAad+H6+ZOC9qRq47VQ=",
      "url": "_framework/dotnet.native.g9vojy1xhm.wasm"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-1iXOS4LgvCcvxYEwE7I5aCvJQQ3gmRvLB7xGG+P7zFM=",
      "url": "_framework/netstandard.e2o8y6kmmh.wasm"
    },
    {
      "hash": "sha256-/IihSrpj7+sP6djzQstWcuY8TuQUp00BP7yP3gqKUnE=",
      "url": "api-spec.yaml"
    },
    {
      "hash": "sha256-0xFOIPewimW0arDNbynbg+FlB3A1AxtNHxH/BN+y6tc=",
      "url": "api/v1/directory.json"
    },
    {
      "hash": "sha256-jrlby8FUUwkx4V/EGMix/pkQlWcUCVUgmeoapZaZnt4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SZcWvi+zAZ0okdsPuQjlc/41gRDxxUnw0TOV9inEbBw=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-peGgxEoQeoBNhhayZdAj6VQcsoDWbnquQVwsodSl+bY=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-c2RN81Gti8Q0ZWR+EQg+QSjOIU3PzhnBZVaqmjm0n+0=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-CP0Ljc20/q18iF62QJASIpEIEd3yP7NdhkmHVyMzfEU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-3PxPeZmJq1O9XnCI+qcDbEh2ugqFhtRDRTJ11Zc4th0=",
      "url": "manifest.webmanifest"
    }
  ]
};
